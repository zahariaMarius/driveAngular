							***Json Plop***
					**api/routers, node_modules folders**
							**api/routers folder**
								**json.js**
				*In this file we create our moiddlware Express*
					*We use json for the various request*
							**node_modules**
				*Here there are All Node's file to work with  the 		server** 
								**app.js**
				*We create Express middleware and we write Javascript function to interact with it*
							**package-lock.json**
				*
							**package.json**
				*									*
							**server.js**
				*We run the file activating the server's port*


